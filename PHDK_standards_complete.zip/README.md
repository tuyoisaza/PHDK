# PHDK Standards Complete Package

Generated: 2026-05-07 15:08

This ZIP contains the full PHDK standards set.

## Included files

- `AGENTS.md`
- `BUILD_APP_FOUNDATION_PROMPT.md`
- `DESIGN_RULES.md`
- `DEVELOPMENT_RULES.md`
- `PROJECT_HANDOFF_TO_DEVELOPMENT_KIT_PROMPT.md`
- `QA_CHECKLIST.md`
- `TECHNICAL_STACK.md`

## Recommended repo use

Put these files in your reusable PHDK standards repository.

The generated project-specific PHDK kit should reference this standards repo and instruct AI coders to fetch the latest versions before coding.
